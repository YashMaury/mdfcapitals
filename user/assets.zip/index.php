<?php
session_start();
include('../admin/inc/function.php');

redirect('../index.php');

?>