<div class="clearfix"></div>
                <footer class="footer container-fluid pt-25">

                    <div class="row margin-balance">
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <p>2021 &copy; phcworld.live All rights reserved.</p>
                        </div>
                    </div>
                </footer>