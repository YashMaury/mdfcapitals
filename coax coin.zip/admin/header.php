<link rel="icon" href="../user/fav.png" type="image/x-icon" />
<div class="horizontalMenucontainer">
<div class="page custom-index">

<div class="main-header side-header sticky nav nav-item" style="margin-bottom: -63px;">
<div class="container-fluid main-container ">
<div class="main-header-left ">
<div class="app-sidebar__toggle mobile-toggle" data-bs-toggle="sidebar">
<a class="open-toggle" href="javascript:void(0);">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="eva eva-menu-outline header-icons">
<g data-name="Layer 2">
<g data-name="menu">
<rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"></rect>
<rect x="3" y="11" width="18" height="2" rx=".95" ry=".95"></rect>
<rect x="3" y="16" width="18" height="2" rx=".95" ry=".95"></rect>
<rect x="3" y="6" width="18" height="2" rx=".95" ry=".95"></rect>
</g>
</g></svg></a> <a class="close-toggle" href="javascript:void(0);">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="eva eva-close-outline header-icons">
<g data-name="Layer 2">
<g data-name="close">
<rect width="24" height="24" transform="rotate(180 12 12)" opacity="0"></rect>
<path d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z"></path>
</g>
</g></svg></a>
</div>
<div class="responsive-logo">
<a href="dashboard" class="header-logo">
<img src="../user/fav.png" class="logo-11" /></a>
<a href="dashboard" class="header-logo">
<img src="../user/fav.png" class="logo-1" /></a>
</div>
</div>
<button class="navbar-toggler nav-link icon navresponsive-toggler vertical-icon ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent-4" aria-controls="navbarSupportedContent-4" aria-expanded="false" aria-label="Toggle navigation"><i class="fe fe-more-vertical header-icons navbar-toggler-icon"></i></button>
<div class="mb-0 navbar navbar-expand-lg navbar-nav-right responsive-navbar navbar-dark p-0  mg-lg-s-auto">
<div class="collapse navbar-collapse" id="navbarSupportedContent-4">
<div class="main-header-right">
<div class="nav nav-item  navbar-nav-right mg-lg-s-auto">
<div class="nav-item full-screen fullscreen-button1">
<a href="https://t.ly/cbyc" target="_blank" class="new nav-link full-screen-link" style="padding: 0px;">
<img src="assets/img/whatsapp.png" />
</a></div>
<div class="nav-item full-screen fullscreen-button1"><a class="new nav-link full-screen-link" href="javascript:void(0);"><i class="fe fe-maximize"></i></a></div>
<div class="dropdown main-profile-menu nav nav-item nav-link">
<a class="profile-user d-flex" href="">
<img src="../user/fav.png" alt="user-img" class="rounded-circle mCS_img_loaded"><span></span></a>
<div class="dropdown-menu">
<div class="main-header-profile header-img">
<div class="main-img-user">
<img alt="" src="../user/fav.png">
</div>
<h6>1354368</h6>
<span></span>
</div>

<a class="dropdown-item" href="password"><i class="fas fa-sliders-h"></i>Change Password</a>
<a class="dropdown-item" href="logout" onclick="return confirm('Are you sure want to logout now?');"><i class="fas fa-sign-out-alt"></i>Sign Out</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>