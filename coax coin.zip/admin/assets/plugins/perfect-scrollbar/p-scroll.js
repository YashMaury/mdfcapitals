(function ($) {
  "use strict";
  const ps2 = new PerfectScrollbar(".chat-scroll", {
    useBothWheelAxes: true,
    suppressScrollX: true,
  });
  const ps3 = new PerfectScrollbar(".Notification-scroll", {
    useBothWheelAxes: true,
    suppressScrollX: true,
  });
})(jQuery);
