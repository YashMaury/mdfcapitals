<?php
session_start();
include ('admin/inc/function.php');
date_default_timezone_set('Asia/Kolkata');
$conn = mysqli_connect('localhost', 'glintqnj_mdfcapitals', 'Glintel@2023', 'glintqnj_mdfcapitals');
// $conn=mysqli_connect('localhost','root','root','mdfcapitals',);
$job_date = date('Y-m-d');
 //$job_date=date('Y-m-d',strtotime(date('Y-m-d') . ' -1 day'));
$count = 0;

if (!$conn)
{
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM `imaksoft_member` order by userid";
$result = mysqli_query($conn, $sql);

if (!$result)
{
    die("Query failed: " . mysqli_error($conn));
}

$users = array();
while ($row = mysqli_fetch_assoc($result))
// if (true)

{
    //echo $row['userid'];
    if (isset($row['userid']))
    // if (true)
    
    {

        array_push($users, $row['userid']);
        // if($row['userid']=="MDF9585695")
        getRoyalityIncome($conn, $row['userid'], $users, 0, $job_date, $count);

        array_splice($users, 0);

    }

}

function getRoyalityIncome($conn, $curr_user, $userid, $k, $job_date, $count)
{
    // if(!empty($userid)){
    print_r($userid);
    // }
     $level = "Level " . $k;
    //As the level1 count is shown in level 2    
    echo $level;
    if ($level == "Level 2")
    {
        echo "*****";
       echo $level1 = $count-1;
        if ($level1 > 0)
        {
            $sqli = "INSERT INTO `imaksoft_commission_royality_roi_records`
    (`userid`, `direct_member`,`date`) VALUES 
    ('" . $curr_user . "','" . $level1 . "','" . date('Y-m-d') . "')";
            $resa = query($conn, $sqli);
        }
    }

    if ($level == "Level 10")
    {
        $level10 = $count-1;
        if ($level10 > 0)
        {
             $sqlu = "UPDATE `imaksoft_commission_royality_roi_records` SET `total_member`='" . $level10 . "' where userid='" . $curr_user . "' and date='" . $job_date . "'";
            $resu = query($conn, $sqlu);

            echo  $getPaidRoyality = getPaidRoyalityAmount($conn, $curr_user);
            echo  $royalityCondition = getLatestRoyalityCondition($conn, $curr_user, $job_date);
            echo "<br>  ";

            $conditionSplit = explode(":", $royalityCondition);

           
            // if($curr_user="MDF9585695")
            // echo "@@@@@@@@@@" . $newroyality = getSettingsRoyality($conn, 11, 51);
            // else
             $newroyality = getSettingsRoyality($conn, $conditionSplit[0], $conditionSplit[1]);

            $splitRoyality = explode(":", $newroyality);

            if ($splitRoyality[0]!="NULL")   
            {
      
            if(isset($getPaidRoyality)){
            if($getPaidRoyality==0)
            {
                 $sqlu1 = "UPDATE `imaksoft_commission_royality_roi_records`SET `business_created`='T' where userid='" . $curr_user . "' and date='" . $job_date . "'";
                query($conn, $sqlu1);

                  $getTotal = sumLevelIncomeForRoyality($conn, $curr_user, $job_date);

               $bonus = ($getTotal * $splitRoyality[1]) / 100;
 
               if($bonus>0){
                $sqla = "INSERT INTO `imaksoft_commission_royality_roi` (`userid`,`plan`,`bonus`,`percentage`,`status`,`date`) 
               VALUES('" . $curr_user . "','" . $splitRoyality[0] . "','" . $bonus . "','" . $splitRoyality[1] . "','R','" . date('Y-m-d') . "')";
                query($conn, $sqla);
              }
            }
               else if (($getPaidRoyality!=0 && $getPaidRoyality != $splitRoyality[0]) and 
                $conditionSplit[0] >= $splitRoyality[2] and 
                $conditionSplit[1] >= $splitRoyality[3])
                {
                     $sqlu1 = "UPDATE `imaksoft_commission_royality_roi_records`SET `business_created`='T' where userid='" . $curr_user . "' and date='" . $job_date . "'";
                    query($conn, $sqlu1);

                     $getTotal = sumLevelIncomeForRoyality($conn, $curr_user, $job_date);

                   $bonus = ($getTotal * $splitRoyality[1]) / 100;
                   if($bonus>0){
                     $sqla = "INSERT INTO `imaksoft_commission_royality_roi` (`userid`,`plan`,`bonus`,`percentage`,`status`,`date`) 
                    VALUES('" . $curr_user . "','" . $splitRoyality[0] . "','" . $bonus . "','" . $splitRoyality[1] . "','R','" . date('Y-m-d') . "')";
                     query($conn, $sqla);
                   }
                }
                else
                {
                    $sqlu1 = "UPDATE `imaksoft_commission_royality_roi_records` SET `business_created`='F' where userid='" . $curr_user . "' and date='" . $job_date . "'";
                    $resu1 = query($conn, $sqlu1);

                }
            }
            }
            else
            {
                $sqlu1 = "UPDATE `imaksoft_commission_royality_roi_records` SET `business_created`='F' where userid='" . $curr_user . "' and date='" . $job_date . "'";
                $resu1 = query($conn, $sqlu1);

            }

        }
         else
            {
                $sqlu1 = "UPDATE `imaksoft_commission_royality_roi_records` SET `business_created`='F' where userid='" . $curr_user . "' and date='" . $job_date . "'";
                $resu1 = query($conn, $sqlu1);

            }
    }

    //get paid royality last amount
    

    echo "<br>";
    $loop_members = array();
    $size = sizeof($userid);
    if ($k < 10)
    {
        for ($i = 0;$i < $size;$i++)
        {
            echo "^^^^^^" . $count++;
            $allUsers = getAllActiveSponsorUserid($conn, $userid[$i], 'userid');

            $total_business = 0;
            if ($allUsers)
            {
                $loop_members = array_merge($loop_members, $allUsers);

            }

        }
        $k = $k + 1;

        getRoyalityIncome($conn, $curr_user, $loop_members, $k, $job_date, $count);
    }

}

echo "JOB COMPLETED";
mysqli_close($conn);
?>
